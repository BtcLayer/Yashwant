| Checklist item | Score | One-sentence reason |
| --- | --- | --- |
| Cohort signals | TBD | Awaiting latest cohort attribution. |
| OOF stacking | TBD | OOF stack verification queued. |
| Calibration + band | TBD | Band thresholds not re-validated yet. |
| Microstructure overlays | TBD | Overlay regen pending. |
| BMA/bandit | TBD | Need live arm telemetry. |
| Purged/embargoed WF-CV | TBD | WF-CV artifacts not re-run. |
| Risk controls | TBD | Risk guardrails mirrored from prior release. |
| Instrumentation/logging | TBD | Emitter/stateful logging smoke TBD. |
| Logs v2 + snapshots | TBD | Snapshot writer not smoke-tested. |