"""Thin wrapper exposing the shared ModelRuntime implementation."""

from live_demo.model_runtime import ModelRuntime

__all__ = ["ModelRuntime"]
