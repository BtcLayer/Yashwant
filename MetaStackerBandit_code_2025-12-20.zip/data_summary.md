| File | Rows | Min TS | Max TS | NaN counts |
| --- | --- | --- | --- | --- |
| equity.csv | 24 | 2025-12-07T22:44:05.714174+05:30 | 2025-12-08T12:44:02.330897+05:30 | ts: 0, equity_value: 0 |
| trade_log.csv | 12 | 2025-12-07T22:44:12.214339+05:30 | 2025-12-08T12:43:57.035420+05:30 | decision_time: 0, exec_time: 0, side: 0, qty: 0, price: 12, transaction_cost: 12 |
| signals.csv | 24 | 2025-12-07T22:44:05.516316+05:30 | 2025-12-08T12:44:02.095060+05:30 | ts: 0, pred_bps: 24, pred_raw: 24, S_top: 24, S_bot: 24, adv20: 24 |